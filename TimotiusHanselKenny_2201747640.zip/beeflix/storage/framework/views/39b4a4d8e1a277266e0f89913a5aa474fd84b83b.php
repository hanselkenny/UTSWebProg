

<?php $__env->startSection('body'); ?>
  <!-- Page Content -->
  <div class="container">

    <div class="row">

      <div class="col-lg-3">

        <h1 class="my-4">Movie Category</h1>
        <div class="list-group">
            <a href="/home" class="list-group-item">All Category</a>
            <?php $__currentLoopData = $genres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <a href="/home/category/<?php echo e($i->id); ?>" class="list-group-item"><?php echo e($i->name); ?></a>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

      </div>
      <div class="col-lg-9">
      <div id="carouselExampleIndicators" class="carousel slide my-4" data-ride="carousel">
        <?php if(isset($genre)): ?>
        <h2>Displaying for Movie Category : <?php echo e($genre->name); ?></h2>
        <?php else: ?>
        <h2>Displaying for All Movie Category </h2>
            <?php endif; ?>
      </div>
      <div class="row">

        <?php $__currentLoopData = $movies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-lg-4 col-md-6 mb-4">
            <div class="card h-100">
            <a href="/home/<?php echo e($i->id); ?>"><img class="card-img-top" src="<?php echo e($i->photo); ?>" alt=""></a>
              <div class="card-body">
                <h4 class="card-title">
                  <a href="/home/<?php echo e($i->id); ?>"><?php echo e($i->title); ?></a>
                </h4>
                <a href="/home/<?php echo e($i->id); ?>">Lihat Film</a>
              </div>
              <div class="card-footer">
                <small class="text-muted">&#9733; &#9733; &#9733; &#9733; &#9734;</small>
              </div>
            </div>
          </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
    </div>
    </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\DOCS KENNY\Onedrive\OneDrive - Bina Nusantara University\SEM 5\Web programming\UTS\beeflix\resources\views/index.blade.php ENDPATH**/ ?>