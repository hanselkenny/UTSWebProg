

<?php $__env->startSection('body'); ?>
    <h2 class="title">Movies</h2>
    <div class="row">
    <div class="col-lg-6">
        <div class="col-lg-6 col-md-6 mb-4">
            <div class="card h-400">
            <a><img class="card-img-top" src="<?php echo e($movies->photo); ?>" alt=""></a>
              <div class="card-body">
                <h4 class="card-title">
                  <a><?php echo e($movies->title); ?></a>
                </h4>
            <a ><?php echo e($movies->description); ?></a>
            <h4>
                <a>Kategori : <?php echo e($genre->name); ?></a>
            </h4>
              </div>
              <div class="card-footer">
                <small class="text-muted">
                    <?php for($i=0;$i<(int)$movies->rating;$i++): ?>
                    &#9733;
                    <?php endfor; ?>
                </small>
              </div>
            </div>
          </div>
    </div>
    <div class="col-lg-6">
    <table class="table">
        <thead>
        <tr>
            <th>Episode</th>
            <th>Judul</th>
        </tr>
        </thead>
        <tbody>
        
        

        <?php $__currentLoopData = $episodes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($i->episode); ?></td>
                <td><?php echo e($i->title); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


        </tbody>
    </table>
    
    
    <?php echo e($episodes->links()); ?>

    </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\DOCS KENNY\Onedrive\OneDrive - Bina Nusantara University\SEM 5\Web programming\UTS\beeflix\resources\views/detail.blade.php ENDPATH**/ ?>